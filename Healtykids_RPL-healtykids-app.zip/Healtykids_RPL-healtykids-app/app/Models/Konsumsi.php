<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Konsumsi extends Model
{
    protected $table = 'konsumsis';

    protected $fillable = ['konsumsi', 'pasien_id', 'dokter_id', 'gizi_id'];

    public function gizi()
    {
        return $this->belongsTo(Gizi::class);
    }
}
