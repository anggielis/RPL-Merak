<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gizi extends Model
{
    protected $table = 'gizis';

    protected $fillable = [
        'gizi',
        'pasien_id',
        'dokter_id'
    ];

    public function pasien()
    {
        return $this->belongsTo(Pasien::class);
    }

    public function dokter()
    {
        return $this->belongsTo(Dokter::class);
    }
}
