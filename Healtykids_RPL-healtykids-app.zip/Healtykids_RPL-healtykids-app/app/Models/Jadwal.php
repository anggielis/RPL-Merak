<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Jadwal extends Model
{
    protected $table = 'jadwals';

    protected $fillable = [
        'dokter_id',
        'schedule',
    ];

    public function dokter()
    {
        return $this->belongsTo(Dokter::class);
    }
}
