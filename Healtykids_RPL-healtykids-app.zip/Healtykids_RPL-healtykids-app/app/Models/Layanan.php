<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Layanan extends Model
{
    protected $table = 'layanans';

    protected $fillable = [
        'layanan',
        'dokter_id',
        'rs',
        'notelp',
    ];

    public function dokter()
    {
        return $this->belongsTo(Dokter::class);
    }
}
