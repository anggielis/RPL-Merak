<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Dokter;
use App\Models\Jadwal;
use App\Models\Pasien;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $user = auth()->user();
    
        // Ambil data dokter sesuai nama user
        $dokter = Dokter::where('nama', $user->name)->first();
    
        // Ambil data booking yang relevan
        $bookingDokter = $dokter ? Booking::where('dokter_id', $dokter->id)->get() : collect(); // Jika $dokter kosong, return collection kosong
        $bookings = Booking::where('user_id', $user->id)->get();
        $bookingAdmin = $user->role == "admin" ? Booking::all() : collect(); // Cek apakah user adalah admin
    
        // Ambil semua data jadwal dokter
        $dokters = Jadwal::all();
    
        return view('booking.index', compact('dokters', 'bookings', 'bookingDokter', 'bookingAdmin'));
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create($id)
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'dokter_id' => 'required',
            'day' => 'required',
            'time' => 'required',
            'pasien' => 'required',
        ]);

        $pasien = Pasien::create([
            'nama' => $request->pasien,
            'user_id' => auth()->user()->id
        ]);

        Booking::create([
            'dokter_id' => $request->dokter_id,
            'day' => $request->day,
            'time' => $request->time,
            'pasien_id' => $pasien->id,
            'status' => 'Pending',
            'user_id' => auth()->user()->id
        ]);

        return redirect()->route('booking.index')->with('success', 'Booking created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Booking $booking)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Booking $booking)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Booking $booking)
    {
        $request->validate([
            'dokter_id' => 'required',
            'pasien_id' => 'required',
            'status' => 'required',
        ]);

        if ($request->status == 'approved') {
            $booking->update([
                'status' => 'Approved'
            ]);
        } else {
            $booking->update([
                'status' => 'Rejected'
            ]);
        }

        return redirect()->route('booking.index')->with('success', 'Booking updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Booking $booking)
    {
        //
    }


    // booking
    public function tambah($id)
    {
        $dokter = Dokter::find($id);
        return view('booking.create', compact('dokter'));
    }
}
