<?php

namespace App\Http\Controllers;

use App\Models\Gizi;
use App\Models\Konsumsi;
use App\Models\Pasien;
use Illuminate\Http\Request;

class GiziController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pasiens = Pasien::all();
        return view('gizi.index', compact('pasiens'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'pasien_id' => 'required',
            'gizi' => 'required',
            'dokter_id' => 'required',
        ]);

        Gizi::create([
            'pasien_id' => $request->pasien_id,
            'gizi' => $request->gizi,
            'dokter_id' => $request->dokter_id
        ]);

        return redirect()->route('gizi.index')->with('success', 'Gizi created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Gizi $gizi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Gizi $gizi)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Gizi $gizi)
    {
        $request->validate([
            'pasien_id' => 'required',
            'gizi' => 'required',
            'dokter_id' => 'required',
        ]);

        $gizi->update([
            'pasien_id' => $request->pasien_id,
            'gizi' => $request->gizi,
            'dokter_id' => $request->dokter_id
        ]);

        return redirect()->route('gizi.index')->with('success', 'Gizi updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Gizi $gizi)
    {
        // Delete related records in konsumsis
        Konsumsi::where('gizi_id', $gizi->id)->delete();

        // Delete the gizi record
        $gizi->delete();

        return redirect()->route('gizi.index')->with('success', 'Gizi deleted successfully.');
    }


    public function tambah($id)
    {
        $pasien = Pasien::find($id);
        return view('gizi.tambah', compact('pasien'));
    }

    public function detail($id)
    {
        $gizis = Gizi::where('pasien_id', $id)->get();
        $konsumsi = Konsumsi::where('pasien_id', $id)->get();
        return view('gizi.detailgizi', compact('gizis', 'konsumsi'));
    }
}
