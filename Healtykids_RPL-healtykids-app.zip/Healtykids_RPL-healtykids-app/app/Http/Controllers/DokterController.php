<?php

namespace App\Http\Controllers;

use App\Models\Dokter;
use App\Models\Jadwal;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DokterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Dokter::all();
        return view('dokter.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('dokter.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'deskripsi' => 'required',
            'spesialis' => 'required',
            'foto' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'email' => 'required',
            'password' => 'required',
            'schedule' => 'required'
        ]);

        if ($request->hasFile('foto')) {
            $request->file('foto')->storeAs('dokter', $request->file('foto')->hashName());
        }

        $dokter = Dokter::create([
            'nama' => $request->nama,
            'deskripsi' => $request->deskripsi,
            'spesialis' => $request->spesialis,
            'foto' => $request->file('foto')->hashName(),
            'schedule' => $request->schedule
        ]);
        
        Jadwal::create([
           'dokter_id' => $dokter->id,
           'schedule' => $request->schedule
        ]);

        User::create([
            'name' => $request->nama,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'role' => 'dokter',
            'user_id' => $dokter->id
        ]);

        return redirect()->route('dokter.index')->with('success', 'Dokter berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     */
    public function show(Dokter $dokter)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Dokter $dokter)
    {
        // Ambil data user berdasarkan email atau kriteria lain
        $user = User::where('name', $dokter->nama)->where('role', 'dokter')->first();
        
        $jadwal = Jadwal::where('dokter_id', $dokter->id)->first();

        // Kirim data ke view
        return view('dokter.edit', compact('dokter', 'user', 'jadwal'));
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Dokter $dokter)
    {
        // Validasi input
        $request->validate([
            'nama' => 'required',
            'deskripsi' => 'required',
            'spesialis' => 'required',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Foto tidak wajib
            'email' => 'required|email',
            'password' => 'nullable|min:6', // Password opsional
            'schedule' => 'required'
        ]);

        // Update foto jika ada file baru
        if ($request->hasFile('foto')) {
            // Hapus file lama jika ada
            if ($dokter->foto && Storage::exists('dokter/' . $dokter->foto)) {
                Storage::delete('dokter/' . $dokter->foto);
            }

            // Simpan file baru
            $newFotoName = $request->file('foto')->hashName();
            $request->file('foto')->storeAs('dokter', $newFotoName);

            // Update foto di model
            $dokter->foto = $newFotoName;
        }

        // Update data Dokter
        $dokter->update([
            'nama' => $request->nama,
            'deskripsi' => $request->deskripsi,
            'spesialis' => $request->spesialis,
            'foto' => $dokter->foto, // Foto sudah diperbarui sebelumnya
        ]);

        // Update data User (berdasarkan nama atau relasi jika ada)
        $user = User::where('role', 'dokter')->where('user_id', $dokter->id)->first();
        if ($user) {
            $user->update([
                'name' => $request->nama,
                'email' => $request->email,
                'password' => $request->password ? bcrypt($request->password) : $user->password, // Password hanya diperbarui jika diisi
            ]);
        }
        
        $jadwal = Jadwal::where('dokter_id', $dokter->id)->first();
        if($jadwal){
            $jadwal->update([
                'schedule' => $request->schedule
            ]);
        }
        

        // Redirect dengan pesan sukses
        return redirect()->route('dokter.index')->with('success', 'Data Dokter berhasil diperbarui.');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Dokter $dokter)
    {
        if ($dokter->foto && Storage::exists('dokter/' . $dokter->foto)) {
            Storage::delete('dokter/' . $dokter->foto);
        }

        $user = User::where('role', 'dokter')->where('user_id', $dokter->id)->first();
        if ($user) {
            $user->delete();
        }
        $dokter->delete();
        return redirect()->route('dokter.index')->with('success', 'Dokter berhasil dihapus');
    }
}
