<?php

namespace App\Http\Controllers;

use App\Models\Dokter;
use App\Models\Gizi;
use App\Models\Konsumsi;
use App\Models\Pasien;
use Illuminate\Http\Request;

class KonsumsiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'gizi_id' => 'required',
            'pasien_id' => 'required',
            'konsumsi' => 'required',
            'dokter_id' => 'required',
        ]);

        Konsumsi::create([
            'gizi_id' => $request->gizi_id,
            'pasien_id' => $request->pasien_id,
            'konsumsi' => $request->konsumsi,
            'dokter_id' => $request->dokter_id
        ]);

        return redirect()->route('gizi.index')->with('success', 'Konsumsi created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Konsumsi $konsumsi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Konsumsi $konsumsi)
    {
        $gizi = Gizi::find($konsumsi->gizi_id);
        $dokter = Dokter::find($gizi->dokter_id);
        $pasien = Pasien::find($gizi->pasien_id);

        return view('konsumsi.edit', compact('konsumsi', 'gizi', 'dokter', 'pasien'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Konsumsi $konsumsi)
    {
        $request->validate([
            'gizi_id' => 'required',
            'pasien_id' => 'required',
            'konsumsi' => 'required',
            'dokter_id' => 'required',
        ]);

        $konsumsi->update([
            'gizi_id' => $request->gizi_id,
            'pasien_id' => $request->pasien_id,
            'konsumsi' => $request->konsumsi,
            'dokter_id' => $request->dokter_id
        ]);

        return redirect()->route('gizi.index')->with('success', 'Konsumsi updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Konsumsi $konsumsi)
    {
        //
    }

    public function tambah($id)
    {
        $gizi = Gizi::find($id);
        $dokter = Dokter::find($gizi->dokter_id);
        $pasien = Pasien::find($gizi->pasien_id);
        return view('konsumsi.create', compact('gizi', 'dokter', 'pasien'));
    }
}
