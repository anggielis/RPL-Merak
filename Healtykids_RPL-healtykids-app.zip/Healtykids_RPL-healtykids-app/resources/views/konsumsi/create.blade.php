@extends('layouts.app')

@section('content')
    <div class="container-fluid" style="padding-bottom: 100px">
        <div class="card p-4">
            <h3>Rekomendasi Konsumsi</h3>
            <form action="{{ route('konsumsi.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="gizi_id" value="{{ $gizi->id }}">
                <input type="hidden" name="dokter_id" value="{{ $dokter->id }}">
                <input type="hidden" name="pasien_id" value="{{ $pasien->id }}">
                <div class="mb-3">
                    <label for="dokter" class="form-label">Dokter</label>
                    <input type="text" name="dokter" class="form-control" id="dokter" value="{{ $dokter->nama }}"
                        disabled>
                </div>

                <div class="mb-3">
                    <label for="pasien" class="form-label">Pasien</label>
                    <input type="text" name="pasien" class="form-control" id="pasien" value="{{ $pasien->nama }}"
                        disabled>
                </div>

                <div class="mb-3">
                    <label for="konsumsi" class="form-label">Rekomendasi</label>
                    <textarea name="konsumsi" id="konsumsi" class="form-control" cols="30" rows="10"></textarea>
                </div>

                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn w-50 d-flex justify-content-center"
                        style="background-color: #1B8182; color: #fff;">Submit</button>
                </div>
            </form>
        </div>
    </div>
@endsection
