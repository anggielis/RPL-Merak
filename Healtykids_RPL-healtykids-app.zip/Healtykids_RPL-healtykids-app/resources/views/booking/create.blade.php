@extends('layouts.app')

@section('content')
    <div class="container-fluid" style="padding-bottom: 100px">
        <div class="card p-4">
            <h3>Booking</h3>
            <form action="{{ route('booking.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="dokter_id" value="{{ $dokter->id }}">
                <div class="mb-3">
                    <label for="dokter" class="form-label">Dokter</label>
                    <input type="text" name="dokter" class="form-control" id="dokter" value="{{ $dokter->nama }}"
                        disabled>
                </div>

                <div class="mb-3">
                    <label for="day" class="form-label">Hari</label>
                    <input type="text" name="day" class="form-control" id="day">
                </div>

                <div class="mb-3">
                    <label for="pasien" class="form-label">Pasien</label>
                    <input type="text" name="pasien" class="form-control" id="pasien">
                </div>

                <div class="mb-3">
                    <label for="time" class="form-label">Pukul</label>
                    <input type="text" name="time" class="form-control" id="time">
                </div>

                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn w-50 d-flex justify-content-center"
                        style="background-color: #1B8182; color: #fff;">Submit</button>
                </div>
            </form>
        </div>
    </div>
@endsection
