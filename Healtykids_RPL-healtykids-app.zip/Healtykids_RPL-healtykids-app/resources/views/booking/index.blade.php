@extends('layouts.app')

@section('content')
    <div class="container-fluid" style="padding-bottom: 100px">

        @if (Auth::user()->role == 'dokter')
            <div class="card p-4 mt-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Booking</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Dokter</th>
                                <th scope="col">Hari</th>
                                <th scope="col">Pasien</th>
                                <th scope="col">Pukul</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($bookingDokter as $item)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}</th>
                                    <th>{{ $item->dokter->nama }}</th>
                                    <th>{{ $item->day }}</th>
                                    <th>{{ $item->pasien->nama }}</th>
                                    <th>{{ $item->time }}</th>

                                    @if ($item->status == 'Approved')
                                        <td>
                                            <span class="badge bg-success text-white">{{ $item->status }}</span>
                                        </td>
                                    @elseif ($item->status == 'Rejected')
                                        <td>
                                            <span class="badge bg-danger text-white">{{ $item->status }}</span>
                                        </td>
                                    @else
                                        <td class="d-flex gap-2">
                                            <form action="{{ route('booking.update', $item->id) }}" method="POST">
                                                @csrf
                                                @method('PUT')
                                                <input type="hidden" name="dokter_id" value="{{ $item->dokter_id }}">
                                                <input type="hidden" name="pasien_id" value="{{ $item->pasien_id }}">
                                                <input type="hidden" name="status" value="approved">

                                                <button type="submit" class="btn btn-success btn-sm">Approve</button>

                                            </form>
                                            <form action="{{ route('booking.update', $item->id) }}" method="POST">
                                                @csrf
                                                @method('PUT')
                                                <input type="hidden" name="dokter_id" value="{{ $item->dokter_id }}">
                                                <input type="hidden" name="pasien_id" value="{{ $item->pasien_id }}">
                                                <input type="hidden" name="status" value="canceled">

                                                <button type="submit" class="btn btn-danger btn-sm">Cancel</button>

                                            </form>
                                        </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @elseif (Auth::user()->role == 'user')
            <div class="card p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Jadwal Dokter</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Dokter</th>
                                <th scope="col">Jadwal</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($dokters as $item)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}</th>
                                    <th>{{ $item->dokter->nama }}</th>
                                    <th>{{ $item->schedule }}</th>
                                    <th>
                                        <a href="{{ route('booking.book', $item->dokter_id) }}"
                                            class="btn btn-primary">Booking</a>
                                    </th>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card p-4 mt-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Booking</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Dokter</th>
                                <th scope="col">Hari</th>
                                <th scope="col">Pasien</th>
                                <th scope="col">Pukul</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($bookings as $item)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}</th>
                                    <th>{{ $item->dokter->nama }}</th>
                                    <th>{{ $item->day }}</th>
                                    <th>{{ $item->pasien->nama }}</th>
                                    <th>{{ $item->time }}</th>
                                    <td class="badge bg-warning text-white">{{ $item->status }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @else
            <div class="card p-4 mt-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Booking</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Dokter</th>
                                <th scope="col">Hari</th>
                                <th scope="col">Pasien</th>
                                <th scope="col">Pukul</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($bookingAdmin as $item)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}</th>
                                    <th>{{ $item->dokter->nama }}</th>
                                    <th>{{ $item->day }}</th>
                                    <th>{{ $item->pasien->nama }}</th>
                                    <th>{{ $item->time }}</th>

                                    @if ($item->status == 'Approved')
                                        <td>
                                            <span class="badge bg-success text-white">{{ $item->status }}</span>
                                        </td>
                                    @elseif ($item->status == 'Rejected')
                                        <td>
                                            <span class="badge bg-danger text-white">{{ $item->status }}</span>
                                        </td>
                                    @else
                                        <td class="d-flex gap-2">
                                            <form action="{{ route('booking.update', $item->id) }}" method="POST">
                                                @csrf
                                                @method('PUT')
                                                <input type="hidden" name="dokter_id" value="{{ $item->dokter_id }}">
                                                <input type="hidden" name="pasien_id" value="{{ $item->pasien_id }}">
                                                <input type="hidden" name="status" value="approved">

                                                <button type="submit" class="btn btn-success btn-sm">Approve</button>

                                            </form>
                                            <form action="{{ route('booking.update', $item->id) }}" method="POST">
                                                @csrf
                                                @method('PUT')
                                                <input type="hidden" name="dokter_id" value="{{ $item->dokter_id }}">
                                                <input type="hidden" name="pasien_id" value="{{ $item->pasien_id }}">
                                                <input type="hidden" name="status" value="canceled">

                                                <button type="submit" class="btn btn-danger btn-sm">Cancel</button>

                                            </form>
                                        </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @endif

    </div>
@endsection
