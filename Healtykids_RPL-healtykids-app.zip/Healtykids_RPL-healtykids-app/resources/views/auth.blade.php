<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .navbar a {
            margin-right: 10px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="bg-light">

    <div class="container d-flex flex-column min-vh-100 justify-content-center">
        <div class="row justify-content-between align-items-center">
            <div class="col-md-6 text-center">
                <img src="{{ asset('assets/img/logo-auth.png') }}" alt="Logo" class="img-fluid" width="300">
            </div>
            <div class="col-md-6 d-flex flex-column gap-3">
                <h2 class="text-center">Login</h2>
                <form action="{{ route('authenticate') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" name="email" class="form-control" id="email"
                            aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="pasword" class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" id="pasword">
                    </div>
                    <div class="mb-3">
                        <small>Belum punya akun? <a href="{{ route('register') }}" class="text-decoration-none"
                                style="color: #1B8182">Daftar</a></small>
                    </div>
                    <button type="submit" class="btn d-flex justify-content-center w-100 rounded-pill"
                        style="background-color: #1B8182; color: white;">Masuk</button>
                </form>
            </div>
        </div>
    </div>

    <nav class="navbar fixed-bottom" style="background-color: #3ad74a;">
        <div class="container text-center">
            <a href="#" class="text-dark text-decoration-none">About</a>
            <a href="#" class="text-dark text-decoration-none">Help Center</a>
            <a href="#" class="text-dark text-decoration-none">Terms of Service</a>
            <a href="#" class="text-dark text-decoration-none">Privacy Policy</a>
            <a href="#" class="text-dark text-decoration-none">Accessibility</a>
            <a href="#" class="text-dark text-decoration-none">Careers</a>
            <a href="#" class="text-dark text-decoration-none">Marketing</a>
            <a href="#" class="text-dark text-decoration-none">Developers</a>
            <a href="#" class="text-dark text-decoration-none">Settings</a>
            <a href="#" class="text-dark text-decoration-none">@2022yanliudesign</a>
        </div>
    </nav>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>

    {{-- Cek jika ada session success --}}
    @if (session('success'))
        <script>
            Swal.fire({
                title: "Success!",
                text: "{{ session('success') }}",
                icon: "success",
                confirmButtonColor: "#3085d6",
                confirmButtonText: "OK"
            });
        </script>
    @elseif (session('error'))
        <script>
            Swal.fire({
                title: "Error!",
                text: "{{ session('error') }}",
                icon: "error",
                confirmButtonColor: "#3085d6",
                confirmButtonText: "OK"
            });
        </script>
    @endif

</body>

</html>
