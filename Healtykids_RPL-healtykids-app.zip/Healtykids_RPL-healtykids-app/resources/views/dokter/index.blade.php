@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        @if (Auth::user()->role == 'admin' || Auth::user()->role == 'dokter')
            <div class="card p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Data Dokter</h2>
                    <a href="{{ route('dokter.create') }}" class="btn btn-success">Tambah</a>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Kategori</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $item)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}</th>
                                    <td>{{ $item->nama }}</td>
                                    <td>{{ $item->spesialis }}</td>
                                    <td class="d-flex gap-2">
                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                            data-target="#detail{{ $item->id }}">
                                            Detail
                                        </button>

                                        <div class="modal fade" id="detail{{ $item->id }}" tabindex="-1" role="dialog"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <!-- Modal Header -->
                                                    <div class="modal-header text-white" style="background-color: #1B8182">
                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                            <i class="bi bi-person-circle me-2"></i>{{ $item->nama }}
                                                        </h5>
                                                        <button class="close" type="button" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true" style="color: white">×</span>
                                                        </button>
                                                    </div>

                                                    <!-- Modal Body -->
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <!-- Image Section -->
                                                            <div class="col-md-4 text-center">
                                                                <img src="{{ asset('storage/dokter/' . $item->foto) }}"
                                                                    class="rounded img-fluid" alt="{{ $item->nama }}"
                                                                    style="max-height: 200px; object-fit: cover;">
                                                            </div>

                                                            <!-- Details Section -->
                                                            <div class="col-md-8">
                                                                <h5 class="mb-3 font-weight-bold">{{ $item->spesialis }}
                                                                </h5>
                                                                <p class="card-text text-muted mb-4">{{ $item->deskripsi }}
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <a href="{{ route('dokter.edit', $item->id) }}"
                                            class="btn btn-warning btn-sm">Edit</a>

                                        <form action="{{ route('dokter.destroy', $item->id) }}" method="POST">@csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @else
            <div class="row justify-content-center align-items-center">
                @foreach ($data as $item)
                    <div class="col-lg-3 col-md-4 col-sm-12" type="button" class="btn btn-primary btn-sm"
                        data-toggle="modal" data-target="#detail{{ $item->id }}">
                        <div class="card p-4 d-flex flex-column align-items-center">
                            <img src="{{ asset('storage/dokter/' . $item->foto) }}" class="card-img-top"
                                alt="{{ $item->nama }}" width="100px">
                            <div class="card-body">
                                <h5 class="card-title">{{ $item->nama }}</h5>
                                <p class="card-text">{{ $item->spesialis }}</p>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="detail{{ $item->id }}" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <!-- Modal Header -->
                                <div class="modal-header text-white" style="background-color: #1B8182">
                                    <h5 class="modal-title" id="exampleModalLabel">
                                        <i class="bi bi-person-circle me-2"></i>{{ $item->nama }}
                                    </h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true" style="color: white">×</span>
                                    </button>
                                </div>

                                <!-- Modal Body -->
                                <div class="modal-body">
                                    <div class="row">
                                        <!-- Image Section -->
                                        <div class="col-md-4 text-center">
                                            <img src="{{ asset('storage/dokter/' . $item->foto) }}"
                                                class="rounded img-fluid" alt="{{ $item->nama }}"
                                                style="max-height: 200px; object-fit: cover;">
                                        </div>

                                        <!-- Details Section -->
                                        <div class="col-md-8">
                                            <h5 class="mb-3 font-weight-bold">{{ $item->spesialis }}
                                            </h5>
                                            <p class="card-text text-muted mb-4">{{ $item->deskripsi }}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
@endsection
