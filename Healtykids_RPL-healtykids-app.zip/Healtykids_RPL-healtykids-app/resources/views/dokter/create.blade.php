@extends('layouts.app')

@section('content')
    <div class="container-fluid" style="padding-bottom: 100px">
        <div class="card p-4">
            <h3>Tambah Dokter</h3>
            <form action="{{ route('dokter.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" name="nama" class="form-control" id="nama">
                </div>
                <div class="mb-3">
                    <label for="deskripsi" class="form-label">Deskripsi</label>
                    <textarea name="deskripsi" id="deskripsi" class="form-control" cols="20" rows="5"></textarea>
                </div>
                <div class="mb-3">
                    <label for="schedule" class="form-label">schedule</label>
                    <input type="text" name="schedule" class="form-control" id="schedule">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" id="email">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="password">
                </div>
                <div class="mb-3">
                    <label for="spesialis" class="form-label">Kategori</label>
                    <input type="spesialis" name="spesialis" class="form-control" id="spesialis"
                        placeholder="Specialist Mata / Umum">
                </div>
                <div class="mb-3">
                    <label for="profil" class="form-label">Profile</label>
                    <input type="file" class="d-block" name="foto" id="profil">
                </div>
                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn w-50 d-flex justify-content-center"
                        style="background-color: #1B8182; color: #fff;">Submit</button>
                </div>
            </form>
        </div>
    </div>
@endsection
