<nav class="navbar fixed-bottom" style="background-color: #3ad74a;">
    <div class="container-fluid">
        <a href="" class="text-dark">About</a>
        <a href="" class="text-dark">Help Center</a>
        <a href="" class="text-dark">Help Center</a>
        <a href="" class="text-dark">Terms of Service</a>
        <a href="" class="text-dark">Privacy Policy</a>
        <a href="" class="text-dark">Accesbility</a>
        <a href="" class="text-dark">Carees</a>
        <a href="" class="text-dark">Marketing</a>
        <a href="" class="text-dark">Developers</a>
        <a href="" class="text-dark">Setting</a>
        <a href="" class="text-dark">@2022yanliudesign</a>
    </div>
</nav>
