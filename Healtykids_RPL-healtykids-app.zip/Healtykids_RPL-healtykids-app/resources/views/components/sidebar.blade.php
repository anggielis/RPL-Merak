<ul class="navbar-nav sidebar sidebar-dark accordion" style="background-color: #1B8182;" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/dashboard">
        <div class="sidebar-brand-icon rotate-n-15">
            <img src="{{ asset('assets/img/logo.png') }}" alt="logo" class="img-fluid" width="25">
        </div>
        <div class="sidebar-brand-text mx-3">
            <img src="{{ asset('assets/img/logo-text.png') }}" alt="logo" class="img-fluid">
        </div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'dokter')
        <li class="nav-item active">
            <a class="nav-link" href="{{ route('pasien.index') }}">
                <img src="{{ asset('assets/icon/pasien.png') }}" alt="" class="img-fluid" width="25">
                <span>Pasien</span></a>
        </li>

        <li class="nav-item active">
            <a class="nav-link" href="{{ route('gizi.index') }}">
                <img src="{{ asset('assets/icon/kesehatan.png') }}" alt="" class="img-fluid" width="25">
                <span>Rek Kesehatan</span></a>
        </li>

        <li class="nav-item active">
            <a class="nav-link" href="{{ route('booking.index') }}">
                <img src="{{ asset('assets/icon/booking.png') }}" alt="" class="img-fluid" width="25">
                <span>Booking</span></a>
        </li>

        <li class="nav-item active">
            <a class="nav-link" href="{{ route('dokter.index') }}">
                <img src="{{ asset('assets/icon/dokter.png') }}" alt="" class="img-fluid" width="25">
                <span>Dokter</span></a>
        </li>
    @elseif (Auth::user()->role == 'user')
        <li class="nav-item active">
            <a class="nav-link" href="{{ route('layanan.index') }}">
                <img src="{{ asset('assets/icon/layanan.png') }}" alt="" class="img-fluid" width="25">
                <span>Jenis Layanan</span></a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="">
                <img src="{{ asset('assets/icon/gizi.png') }}" alt="" class="img-fluid" width="25">
                <span>Gizi</span></a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="{{ route('booking.index') }}">
                <img src="{{ asset('assets/icon/booking.png') }}" alt="" class="img-fluid" width="25">
                <span>Booking</span></a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="{{ route('about') }}">
                <img src="{{ asset('assets/icon/about.png') }}" alt="" class="img-fluid" width="25">
                <span>About</span></a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="{{ route('dokter.index') }}">
                <img src="{{ asset('assets/icon/dokter.png') }}" alt="" class="img-fluid" width="25">
                <span>Dokter</span></a>
        </li>
    @endif

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

</ul>
