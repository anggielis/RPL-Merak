@extends('layouts.app')

@section('content')
    <div class="container-fluid" style="padding-bottom: 100px">
        <div class="card p-4">
            <h3>Edit Pasien</h3>
            <form action="{{ route('pasien.update', $pasien->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama Pasien</label>
                    <input type="text" name="nama" class="form-control" id="nama" value="{{ $pasien->nama }}">
                </div>

                <div class="mb-3">
                    <label for="berat" class="form-label">Berat Badan</label>
                    <input type="text" name="berat" class="form-control" id="berat" value="{{ $pasien->berat }}">
                </div>

                <div class="mb-3">
                    <label for="tinggi" class="form-label">Tinggi Badan</label>
                    <input type="text" name="tinggi" class="form-control" id="tinggi" value="{{ $pasien->tinggi }}">
                </div>

                <div class="mb-3">
                    <label for="usia" class="form-label">Usia</label>
                    <input type="text" name="usia" class="form-control" id="usia" value="{{ $pasien->usia }}">
                </div>

                <div class="mb-3">
                    <label for="berat" class="form-label">Jenis Kelamin</label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="jenkel" id="lakilaki" value="L"
                            {{ $pasien->jenkel == 'L' ? 'checked' : '' }}>
                        <label class="form-check-label" for="lakilaki">
                            Laki-Laki
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="jenkel" id="perempuan" value="P"
                            {{ $pasien->jenkel == 'P' ? 'checked' : '' }}>
                        <label class="form-check-label" for="perempuan">
                            Perempuan
                        </label>
                    </div>
                </div>

                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn w-50 d-flex justify-content-center"
                        style="background-color: #1B8182; color: #fff;">Submit</button>
                </div>
            </form>
        </div>
    </div>
@endsection
