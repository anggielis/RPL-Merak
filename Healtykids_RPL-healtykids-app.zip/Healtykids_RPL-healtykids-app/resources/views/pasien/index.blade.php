@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2>Data Pasien</h2>
                <a href="{{ route('pasien.create') }}" class="btn btn-success">Tambah</a>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Berat Badan</th>
                            <th scope="col">Usia</th>
                            <th scope="col">Jenis Kelamin</th>
                            <th scope="col">Tinggi Badan</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($pasiens as $item)
                            <tr>
                                <th scope="row">{{ $loop->iteration }}</th>
                                <td>{{ $item->nama }}</td>
                                <td>{{ $item->berat }}</td>
                                <td>{{ $item->usia }}</td>
                                <td>
                                    {{ $item->jenkel == 'L' ? 'Laki-laki' : ($item->jenkel == 'P' ? 'Perempuan' : '') }}
                                </td>
                                <td>{{ $item->tinggi }}</td>
                                <td class="d-flex gap-2">
                                    <a href="{{ route('pasien.edit', $item->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                    <form action="{{ route('pasien.destroy', $item->id) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
