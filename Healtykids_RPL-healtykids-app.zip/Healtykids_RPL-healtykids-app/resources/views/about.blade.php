@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        <!-- Content Row -->
        <div class="row justify-content-center align-items-center">

            <!-- Description Section -->
            <div class="col-xl-6 col-md-6 mb-4">
                <p class="text-justify" style="color: #7CB26F; font-size: 20px">
                    Healthy Kids adalah aplikasi ringan, cepat, dan kuat yang dirancang untuk membantu orang tua
                    memantau dan meningkatkan kesehatan anak-anak mereka. Dengan fitur seperti panduan nutrisi yang
                    dipersonalisasi, konsultasi gizi, dan tips kesehatan harian, Healthy Kids memudahkan Anda
                    melacak pertumbuhan anak Anda, mengatur pola makan, dan mendorong gaya hidup aktif. Tujuan kami
                    adalah menciptakan masa depan yang lebih sehat dan bahagia bagi anak-anak di mana pun!
                </p>
                <!-- Contact Information -->
                <div class="d-flex flex-column gap-2 ">
                    <div class="d-flex" style="display: flex; align-items: center; gap: 10px">
                        <img src="{{ asset('assets/icon/instagram.png') }}" alt="Instagram Icon" class="img-fluid">
                        <span>@HealthyKids</span>
                    </div>
                    <div class="d-flex" style="display: flex; align-items: center; gap: 10px">
                        <img src="{{ asset('assets/icon/email.png') }}" alt="Email Icon" class="img-fluid">
                        <span>healthykidsmerak@sehat.id</span>
                    </div>
                </div>
            </div>

            <!-- Image Section -->
            <div class="col-xl-6 col-md-6 mb-4">
                <img src="{{ asset('assets/img/logo-auth.png') }}" class="img-fluid" alt="Healthy Kids Logo" width="300">
            </div>

        </div>
    </div>
@endsection
