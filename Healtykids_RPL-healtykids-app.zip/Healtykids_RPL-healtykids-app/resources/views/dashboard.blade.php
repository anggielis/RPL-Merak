@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        <!-- Content Row -->
        <div class="row justify-content-center align-items-center">

            <div class="col-xl-6 col-md-6 mb-4">
                <a href="{{ route('booking.index') }}">
                    <div class="card shadow h-100 py-2" style="background-color: #1B8182;">
                        <div class="card-body d-flex flex-column align-items-center justify-content-center">
                            <img src="{{ asset('assets/img/jadwal.png') }}" alt="" width="100px">
                            <h2 class="text-white font-weight-bold mt-3">Booking Konsultasi</h2>
                        </div>
                    </div>
                </a>
            </div>

            @if (Auth::user()->role == 'dokter' || Auth::user()->role == 'admin')
                <div class="col-xl-6 col-md-6 mb-4">
                    <a href="{{ route('gizi.index') }}">
                        <div class="card shadow h-100 py-2" style="background-color: #1B8182;">
                            <div class="card-body d-flex flex-column align-items-center justify-content-center">
                                <img src="{{ asset('assets/img/kesehatan.png') }}" alt="" width="100px">
                                <h2 class="text-white font-weight-bold mt-3">Rekomendasi Kesehatan</h2>
                            </div>
                        </div>
                    </a>
                </div>
            @elseif (Auth::user()->role == 'user')
                <div class="col-xl-6 col-md-6 mb-4">
                    <a href="{{ route('gizi.index') }}">
                        <div class="card shadow h-100 py-2" style="background-color: #1B8182;">
                            <div class="card-body d-flex flex-column align-items-center justify-content-center">
                                <img src="{{ asset('assets/img/gizi.png') }}" alt="" width="100px">
                                <h2 class="text-white font-weight-bold mt-3">Daftar Gizi Pada Anak</h2>
                            </div>
                        </div>
                    </a>
                </div>
            @endif



        </div>
    </div>
@endsection
