@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2>Data Layanan</h2>
                <a href="{{ route('layanan.create') }}" class="btn btn-success">Tambah</a>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Jenis Layanan</th>
                            <th scope="col">Dokter</th>
                            <th scope="col">Rumah Sakit</th>
                            <th scope="col">No. Telp</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data as $item)
                            <tr>
                                <th scope="row">{{ $loop->iteration }}</th>
                                <td>{{ $item->layanan }}</td>
                                <td>{{ $item->dokter->nama }}</td>
                                <td>{{ $item->rs }}</td>
                                <td>{{ $item->notelp }}</td>
                                <td>
                                    <a href="{{ route('layanan.edit', $item->id) }}" class="btn btn-warning">Edit</a>
                                    <form action="{{ route('layanan.destroy', $item->id) }}" method="POST"
                                        class="d-inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
