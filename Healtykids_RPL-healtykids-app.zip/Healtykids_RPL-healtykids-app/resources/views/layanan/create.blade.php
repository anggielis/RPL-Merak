@extends('layouts.app')

@section('content')
    <div class="container-fluid" style="padding-bottom: 100px">
        <div class="card p-4">
            <h3>Tambah Layanan</h3>
            <form action="{{ route('layanan.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="mb-3">
                    <label for="layanan" class="form-label">Jenis Layanan</label>
                    <input type="text" name="layanan" class="form-control" id="layanan">
                </div>

                <div class="mb-3">
                    <label for="dokter" class="form-label">Dokter</label>
                    <select name="dokter_id" id="dokter" class="form-control">
                        @foreach ($dokters as $dokter)
                            <option value="{{ $dokter->id }}">{{ $dokter->nama }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="rs" class="form-label">Rumah Sakit</label>
                    <input type="text" name="rs" class="form-control" id="rs">
                </div>

                <div class="mb-3">
                    <label for="notelp" class="form-label">No Telepon</label>
                    <input type="text" name="notelp" class="form-control" id="notelp">
                </div>

                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn w-50 d-flex justify-content-center"
                        style="background-color: #1B8182; color: #fff;">Submit</button>
                </div>
            </form>
        </div>
    </div>
@endsection
