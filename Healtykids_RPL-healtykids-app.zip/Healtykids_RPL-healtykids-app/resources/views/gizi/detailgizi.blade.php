@extends('layouts.app')

@section('content')
    <div class="container-fluid" style="padding-bottom: 100px">

        @if (Auth::user()->role == 'dokter' || Auth::user()->role == 'admin')
            <div class="card p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Gizi</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Gizi</th>
                                <th scope="col">Konsumsi</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($gizis as $item)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}</th>
                                    <td>{{ $item->gizi }}</td>
                                    <td>
                                        <a href="{{ route('konsumsi.tambah', $item->id) }}"
                                            class="btn btn-success btn-sm">Add</a>
                                    </td>
                                    <td class="d-flex gap-2">
                                        <form action="{{ route('gizi.destroy', $item->id) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm"><svg
                                                    xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                    fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                                                    <path
                                                        d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                                                </svg>
                                            </button>
                                        </form>
                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                            data-target="#edit{{ $item->id }}">
                                            Edit Gizi
                                        </button>

                                        <div class="modal fade" id="edit{{ $item->id }}" tabindex="-1" role="dialog"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <!-- Modal Header -->
                                                    <div class="modal-header text-white" style="background-color: #1B8182">
                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                            <i class="bi bi-person-circle me-2"></i>
                                                            {{ $item->pasien->nama }}
                                                        </h5>
                                                        <button class="close" type="button" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true" style="color: white">×</span>
                                                        </button>
                                                    </div>

                                                    <!-- Modal Body -->
                                                    <div class="modal-body">
                                                        <form action="{{ route('gizi.update', $item->id) }}" method="POST">
                                                            @csrf
                                                            @method('PUT')
                                                            <input type="hidden" name="pasien_id"
                                                                value="{{ $item->pasien->id }}">
                                                            <input type="hidden" name="dokter_id"
                                                                value="{{ auth()->user()->id }}">
                                                            <div class="mb-3">
                                                                <label for="gizi">Kandungan Gizi</label>
                                                                <input type="text" class="form-control" name="gizi"
                                                                    value="{{ $item->gizi }}">
                                                            </div>
                                                            <button type="submit" class="btn btn-success">Simpan</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @endif


        <div class="card p-4 mt-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2>Konsumsi</h2>
            </div>
            <div class="table-responsive">
                <table class="table" border="1">
                    <thead>
                        <tr class="text-center bg-success">
                            <th scope="col">Gizi</th>
                            <th scope="col">Konsumsi</th>
                            @if (auth()->user()->role == 'dokter' || auth()->user()->role == 'admin')
                                <th scope="col">Action</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($konsumsi as $item)
                            <tr>
                                <td>{{ $item->gizi->gizi }}</td>
                                <td>{{ $item->konsumsi }}</td>
                                @if (auth()->user()->role == 'dokter' || auth()->user()->role == 'admin')
                                    <td>
                                        <a href="{{ route('konsumsi.edit', $item->id) }}"
                                            class="btn btn-primary btn-sm">Edit</a>
                                    </td>
                                @endif
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
