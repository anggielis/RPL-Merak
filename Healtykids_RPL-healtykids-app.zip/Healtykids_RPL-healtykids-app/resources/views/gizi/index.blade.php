@extends('layouts.app')

@section('content')
    <div class="container-fluid" style="padding-bottom: 100px">

        @if (auth()->user()->role == 'admin' || auth()->user()->role == 'dokter')
            <div class="card p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Gizi</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Berat Badan</th>
                                <th scope="col">Usia</th>
                                <th scope="col">Jenis Kelamin</th>
                                <th scope="col">Tinggi Badan</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pasiens as $item)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}</th>
                                    <td>{{ $item->nama }}</td>
                                    <td>{{ $item->berat }}</td>
                                    <td>{{ $item->usia }}</td>
                                    <td>
                                        {{ $item->jenkel == 'L' ? 'Laki-laki' : ($item->jenkel == 'P' ? 'Perempuan' : '') }}
                                    </td>
                                    <td>{{ $item->tinggi }}</td>
                                    <td class="d-flex gap-2">
                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                            data-target="#addGizi{{ $item->id }}">
                                            Input Gizi
                                        </button>
                                        <a href="{{ route('gizi.detail', $item->id) }}"
                                            class="btn btn-warning btn-sm">Detail
                                            Gizi</a>
                                    </td>
                                </tr>
                                {{-- modal input gizi --}}
                                <div class="modal fade" id="addGizi{{ $item->id }}" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <!-- Modal Header -->
                                            <div class="modal-header text-white" style="background-color: #1B8182">
                                                <h5 class="modal-title" id="exampleModalLabel">
                                                    <i class="bi bi-person-circle me-2"></i>{{ $item->nama }}
                                                </h5>
                                                <button class="close" type="button" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true" style="color: white">×</span>
                                                </button>
                                            </div>

                                            <!-- Modal Body -->
                                            <div class="modal-body">
                                                <form action="{{ route('gizi.store') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="pasien_id" value="{{ $item->id }}">
                                                    <input type="hidden" name="dokter_id"
                                                        value="{{ auth()->user()->id }}">
                                                    <div class="mb-3">
                                                        <label for="gizi">Kandungan Gizi</label>
                                                        <input type="text" class="form-control" name="gizi">
                                                    </div>
                                                    <button type="submit" class="btn btn-success">Simpan</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @else
            <div class="card p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Gizi</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Berat Badan</th>
                                <th scope="col">Usia</th>
                                <th scope="col">Jenis Kelamin</th>
                                <th scope="col">Tinggi Badan</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pasiens as $item)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}</th>
                                    <td>{{ $item->nama }}</td>
                                    <td>{{ $item->berat }}</td>
                                    <td>{{ $item->usia }}</td>
                                    <td>
                                        {{ $item->jenkel == 'L' ? 'Laki-laki' : ($item->jenkel == 'P' ? 'Perempuan' : '') }}
                                    </td>
                                    <td>{{ $item->tinggi }}</td>
                                    <td class="d-flex gap-2">
                                        <a href="{{ route('gizi.detail', $item->id) }}"
                                            class="btn btn-warning btn-sm">Detail
                                            Gizi</a>
                                    </td>
                                </tr>
                                {{-- modal input gizi --}}
                                <div class="modal fade" id="addGizi{{ $item->id }}" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <!-- Modal Header -->
                                            <div class="modal-header text-white" style="background-color: #1B8182">
                                                <h5 class="modal-title" id="exampleModalLabel">
                                                    <i class="bi bi-person-circle me-2"></i>{{ $item->nama }}
                                                </h5>
                                                <button class="close" type="button" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true" style="color: white">×</span>
                                                </button>
                                            </div>

                                            <!-- Modal Body -->
                                            <div class="modal-body">
                                                <form action="{{ route('gizi.store') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="pasien_id" value="{{ $item->id }}">
                                                    <input type="hidden" name="dokter_id"
                                                        value="{{ auth()->user()->id }}">
                                                    <div class="mb-3">
                                                        <label for="gizi">Kandungan Gizi</label>
                                                        <input type="text" class="form-control" name="gizi">
                                                    </div>
                                                    <button type="submit" class="btn btn-success">Simpan</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="row justify-content-center">
                    <div class=" col-lg-6 col-md-6">
                        <img src="{{ asset('assets/img/gizi-1.jpg') }}" alt="gizi" class="img-fluid">
                    </div>
                    <div class=" col-lg-6 col-md-6">
                        <img src="{{ asset('assets/img/gizi-2.jpg') }}" alt="gizi" class="img-fluid">
                    </div>
                </div>
            </div>
        @endif
    </div>
@endsection
