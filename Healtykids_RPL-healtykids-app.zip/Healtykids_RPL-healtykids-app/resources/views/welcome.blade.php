<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Healthy Kids</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero-section {
            background-color: #f8f9fa;
            padding: 100px 0;
        }

        .hero-section img {
            max-width: 100%;
            height: auto;
        }

        .section-title {
            font-weight: bold;
            font-size: 2rem;
        }

        .card {
            border: none;
            text-align: center;
        }

        .footer {
            background-color: #f8f9fa;
            padding: 20px 0;
            text-align: center;
        }

        .doctor-img {
            border-radius: 50%;
            width: 120px;
            height: 120px;
            object-fit: cover;
        }
    </style>
</head>

<body>

    {{-- navbar --}}
    <nav class="navbar navbar-expand-lg bg-white sticky-top shadow-sm">
        <div class="container">
            <img src="{{ asset('assets/img/logo.png') }}" alt="" class="img-fluid" width="25">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">HOME</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">ABOUT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">LAYANAN</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">BOOKING</a>
                    </li>
                </ul>
                <a href="{{ route('login') }}" class="btn" style="background-color: #1B8182; color: white">Login</a>
            </div>
        </div>
    </nav>
    {{-- navbar --}}

    <!-- Hero Section -->
    <section class="hero-section text-center d-flex align-items-center">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-start">
                    <h1 class="section-title">Healthy Kids</h1>
                    <p>Healthy Kids is an application designed to help parents monitor and improve their children's
                        health. This app provides features such as nutritional guidance, fun physical activities, and
                        daily health tips. With Healthy Kids, parents can easily track their child's growth, record
                        their diet, and ensure their child stays active and healthy.</p>
                    <button class="btn btn-primary">Learn More</button>
                </div>
                <div class="col-md-6">
                    <img src="{{ asset('assets/img/logo-auth.png') }}" alt="Healthy Kids Logo" width="300">
                </div>
            </div>
        </div>
    </section>

    <!-- Content Section -->
    <section class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2 class="text-center section-title">Healthy Kids: Light, Fast & Powerful</h2>
                <p>Healthy Kids is an application designed to help parents monitor their children's health. This app
                    provides nutritional guidance, physical activity and daily health tips. With Healthy Kids, parents
                    can track their child's growth, record their eating patterns, and ensure their child stays healthy.
                </p>
                <div class="row justify-content-between align-items-center">
                    <div class="col-md-6">
                        <img src="{{ asset('assets/img/icon.png') }}" alt="">
                        <span class="d-block fw-bold my-2">Title Goes Here</span>
                        <small>Healthy Kids is a user-friendly application designed to support parents in maintaining
                            their
                            children's health.</small>
                    </div>
                    <div class="col-md-6">
                        <img src="{{ asset('assets/img/icon.png') }}" alt="">
                        <span class="d-block fw-bold my-2">Title Goes Here</span>
                        <small>Healthy Kids focuses on supporting parents with practical tools to ensure their
                            children’s
                            health and happiness.</small>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <img src="{{ asset('assets/img/thumbnail-1.jpg') }}" class="img-fluid rounded" alt="Health Image">
            </div>
        </div>
    </section>

    <!-- Feature Section -->
    <section class="container my-5">
        <div class="row g-4">
            <div class="col-md-6">
                <img src="{{ asset('assets/img/thumbnail-2.jpg') }}" class="img-fluid rounded" alt="Feature Image">
            </div>
            <div class="col-md-6">
                <h2 class="section-title">Healthy Kids: Light, Fast & Powerful.</h2>
                <p>Healthy Kids is an application designed to help parents monitor and improve their children's health.
                    It offers features such as nutrition guides, fun physical activities, and daily health tips. With
                    Healthy Kids, parents can easily track their child's growth, record eating patterns, and ensure they
                    stay active and healthy.</p>
            </div>
        </div>
    </section>

    <section class="container my-5">
        <div class="row g-4">
            <div class="col-md-6">
                <img src="{{ asset('assets/img/thumbnail-3.jpg') }}" class="img-fluid rounded" alt="Feature Image">
            </div>
            <div class="col-md-6">
                <h2 class="section-title">Healthy Kids: Light, Fast & Powerful.</h2>
                <p>Healthy Kids is an application designed to help parents monitor and improve their children's health.
                    It offers features such as nutrition guides, fun physical activities, and daily health tips. With
                    Healthy Kids, parents can easily track their child's growth, record eating patterns, and ensure they
                    stay active and healthy.</p>
            </div>
        </div>
    </section>

    <section class="container my-5">
        <div class="row g-4">
            <div class="col-md-6">
                <img src="{{ asset('assets/img/gizi-menu.png') }}" class="img-fluid rounded" alt="Feature Image">
            </div>
            <div class="col-md-6">
                <h2 class="section-title">Healthy Kids: Light, Fast & Powerful.</h2>
                <p>Healthy Kids is an application designed to help parents monitor and improve their children's health.
                    It offers features such as nutrition guides, fun physical activities, and daily health tips. With
                    Healthy Kids, parents can easily track their child's growth, record eating patterns, and ensure they
                    stay active and healthy.</p>
            </div>
        </div>
    </section>

    <!-- Doctor Section -->
    <section class="container my-5">
        <h2 class="text-center section-title">Our Doctors</h2>
        <div class="row text-center mt-4">

            @foreach ($doctors as $item)
                <div class="col-md-6 col-lg-4">
                    <div class="card">
                        <img src="{{ asset('storage/dokter/' . $item->foto) }}" alt="{{ $item->nama }}"
                            class="doctor-img mx-auto rounded-circle">
                        <h5 class="mt-3">{{ $item->nama }}</h5>
                        <p>Dokter {{ $item->spesialis }}</p>
                    </div>
                </div>
            @endforeach
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2023 Healthy Kids | All Rights Reserved</p>
            <div class="d-flex justify-content-center">
                <a href="#" class="text-decoration-none mx-2">Home</a>
                <a href="#" class="text-decoration-none mx-2">About</a>
                <a href="#" class="text-decoration-none mx-2">Contact</a>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
