<?php

use App\Http\Controllers\AuthenticationController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\DokterController;
use App\Http\Controllers\GiziController;
use App\Http\Controllers\KonsumsiController;
use App\Http\Controllers\LayananController;
use App\Http\Controllers\PasienController;
use App\Models\Dokter;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    $doctors = Dokter::all();
    return view('welcome', compact('doctors'));
});

Route::get('/auth', [AuthenticationController::class, 'login'])->name('login');
Route::get('/register', [AuthenticationController::class, 'register'])->name('register');
Route::post('/authenticate', [AuthenticationController::class, 'authenticate'])->name('authenticate');
Route::post('/regist', [AuthenticationController::class, 'regist'])->name('regist');

Route::middleware('auth')->group(function () {

    Route::post('/logout', [AuthenticationController::class, 'logout'])->name('logout');

    Route::get('/dashboard', [AuthenticationController::class, 'dashboard'])->name('dashboard');

    Route::get('/about', function () {
        return view('about');
    })->name('about');

    // Dokter
    Route::resource('dokter', DokterController::class);
    // Layanan
    Route::resource('layanan', LayananController::class);
    // Booking
    Route::resource('booking', BookingController::class);
    // Pasien
    Route::resource('pasien', PasienController::class);
    // Gizi
    Route::resource('gizi', GiziController::class);
    // Konsumsi
    Route::resource('konsumsi', KonsumsiController::class);

    Route::get('/booking-add/{id}', [BookingController::class, 'tambah'])->name('booking.book');
    Route::get('/gizi-add/{id}', [GiziController::class, 'tambah'])->name('gizi.tambah');
    Route::get('/gizi-detail/{id}', [GiziController::class, 'detail'])->name('gizi.detail');

    Route::get('/konsumsi-add/{id}', [KonsumsiController::class, 'tambah'])->name('konsumsi.tambah');
});
